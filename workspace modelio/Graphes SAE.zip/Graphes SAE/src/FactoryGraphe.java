import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("76129f9e-6686-4612-9702-b15c05902827")
public abstract class FactoryGraphe {
    @objid ("3fc7cf9e-41dc-446e-b0b6-3c4b9d4382b3")
    public Noeud creerNoeud(String nom, List<Double> pos, double radius) {
    }

    @objid ("1cb89d1f-c7c9-44b5-a580-deddaee03dfe")
    public Lien creerLien(List<Noeud> noeuds) {
    }

}
