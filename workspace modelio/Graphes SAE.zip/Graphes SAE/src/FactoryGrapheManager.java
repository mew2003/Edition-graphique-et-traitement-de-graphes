import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5a33328b-a932-4827-9907-6562dd84c940")
public class FactoryGrapheManager {
    @objid ("88d54056-fa2c-4fe9-8d35-43b4bd27e165")
    private List<FactoryGraphe> factories = new ArrayList<FactoryGraphe> ();

    @objid ("1595b1c2-1487-4946-ae30-bbeeffe9591f")
    private List<FactoryGrapheManager> instance = new ArrayList<FactoryGrapheManager> ();

    @objid ("7120397c-9769-4ce0-8799-dc94b91304d6")
    private FactoryGrapheManager() {
    }

    @objid ("e57a3e79-1ccb-455c-af3e-7e8397a01348")
    public static FactoryGrapheManager getInstance() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.instance;
    }

}
