import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("edc50e35-8e43-4611-a3de-17d1fa1ec427")
public class FactoryGrapheNonOriente extends FactoryGraphe {
    @objid ("94f3a380-54e4-4874-b370-1e15e5310eab")
    private static List<FactoryGrapheNonOriente> instance = new ArrayList<FactoryGrapheNonOriente> ();

    @objid ("1db50f82-2447-4133-811b-5f46b4f409a6")
    public static FactoryGrapheNonOriente getInstance() {
    }

    @objid ("d7768c44-e35c-4a22-a78f-3c95bd250e4a")
    public Noeud creerNoeud(String nom, double posX, double posY, double radius) {
    }

    @objid ("f34b79bc-aa43-44c0-b255-4b103e0629f0")
    public Lien creerLien(List<Noeud> noeuds) {
    }

}
