import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("8dd5bb30-f38c-4d6f-9b89-46382bd53375")
public class FactoryGrapheOriente extends FactoryGraphe {
    @objid ("6bed1625-fa3d-4590-ba4b-b8cc462f90bb")
    private static List<FactoryGrapheOriente> instance = new ArrayList<FactoryGrapheOriente> ();

    @objid ("f407bff5-4635-4b0f-add0-28576c5bf991")
    public Noeud creerNoeud(String nom, double posX, double posY, double radius) {
    }

    @objid ("56aaaf1d-ee6d-4e91-be2c-1cb76fbf33a4")
    public Lien creerLien(List<Noeud> noeuds) {
    }

    @objid ("6dda258f-a9fa-4d6d-bb94-4da295e9d500")
    public static List<FactoryGrapheOriente> getInstance() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return instance;
    }

}
