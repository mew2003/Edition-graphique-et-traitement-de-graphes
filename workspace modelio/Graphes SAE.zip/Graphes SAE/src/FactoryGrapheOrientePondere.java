import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7b43d460-fed2-4d17-9411-de4c3a106c40")
public class FactoryGrapheOrientePondere extends FactoryGraphe {
    @objid ("b30c03a8-88b6-4d41-96d7-5339321a5235")
    private static List<FactoryGrapheOrientePondere> instance = new ArrayList<FactoryGrapheOrientePondere> ();

    @objid ("b74f1e86-0a53-495a-96c0-aaea827f8ec7")
    public Noeud creerNoeud(String nom, double posX, double posY, double radius) {
    }

    @objid ("660a83df-1106-435c-b526-395de027271d")
    public Lien creerLien(List<Noeud> noeuds) {
    }

    @objid ("aa715714-a545-47e3-902a-55865b90d9f8")
    public static List<FactoryGrapheOrientePondere> getInstance() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.instance;
    }

}
