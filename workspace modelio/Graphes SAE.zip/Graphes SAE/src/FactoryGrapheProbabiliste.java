import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f5605929-f708-4da1-8557-d0d4a4ffcd77")
public class FactoryGrapheProbabiliste extends FactoryGraphe {
    @objid ("c797c52b-51fe-4ccd-8eba-2f92b32dd2fa")
    private static List<FactoryGrapheProbabiliste> instance = new ArrayList<FactoryGrapheProbabiliste> ();

    @objid ("23367389-9212-4b61-97f5-60e5cec47cce")
    public Noeud creerNoeud(String nom, double posX, double posY, double radius) {
    }

    @objid ("e1ea0e68-1763-4072-9b92-232f39be2724")
    public Lien creerLien(List<Noeud> noeuds) {
    }

    @objid ("56986cd6-21db-428e-8cb8-72a23a146695")
    public static List<FactoryGrapheProbabiliste> getInstance() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.instance;
    }

}
