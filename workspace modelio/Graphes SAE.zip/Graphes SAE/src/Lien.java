import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1ed20f91-14a9-4543-996e-4b4cb6fd819f")
public abstract class Lien {
    @objid ("0f9b0ede-9657-46b5-9237-b7f484138bec")
    private Noeud[] noeuds = new Noeud[2];

    @objid ("dbb15c42-e6e3-4db1-bc4f-d3d2908a813a")
    public Noeud[] getNoeuds() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.noeuds;
    }

    @objid ("337f32f0-18fb-41c7-893d-0ab0e2ec1a56")
    public void setNoeuds(Noeud[] value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.noeuds = value;
    }

    @objid ("82277d7a-4dff-483a-bbb3-3528f38482fd")
    public void dessinerLien() {
    }

    @objid ("feb783e9-ecfb-4b42-af48-ae8a02391b5a")
    public Lien(List<Noeud> noeuds);

}
