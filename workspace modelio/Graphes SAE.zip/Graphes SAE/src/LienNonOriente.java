import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("330d2793-fcb3-4bc8-95fa-58b442a3b830")
public class LienNonOriente extends Lien {
    @objid ("cc22b5a6-481d-48e5-8788-8996e4c3fa1e")
    public LienNonOriente(List<Noeud> noeuds) {
    }

}
