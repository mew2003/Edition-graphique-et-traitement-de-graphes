import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("633953c8-33c9-4a09-b06a-0ef6bf969b52")
public class LienOriente extends Lien {
    @objid ("aeeebc3f-6d57-41cd-af5a-08157ca1f50e")
    public LienOriente(List<Noeud> noeuds) {
    }

}
