import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f35fcf89-3722-4bdc-bc0a-9e50a511c651")
public class LienOrientePondere extends Lien {
    @objid ("a234c689-453d-4a6a-ad95-f3eccc200f0b")
    private int valeur;

    @objid ("d4a64efe-d4ba-496e-80c2-7fa9e9189e08")
    public int getValeur() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.valeur;
    }

    @objid ("cdbdde65-0f4c-45a0-af2c-dca8370ead15")
    public void setValeur(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.valeur = value;
    }

    @objid ("0e969ce9-f95e-48e8-835b-e6b7bdf534d5")
    public LienOrientePondere(List<Noeud> noeuds) {
    }

}
