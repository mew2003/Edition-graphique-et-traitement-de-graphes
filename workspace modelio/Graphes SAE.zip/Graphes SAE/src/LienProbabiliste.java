import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f0ed4ee0-104d-4fa6-bb2c-8dd2567199fa")
public class LienProbabiliste extends Lien {
    @objid ("0ac2d68e-3245-4262-ab40-983a40902cf4")
    private double valeur;

    @objid ("e6178dc4-ba1d-49e8-be14-723dae569443")
    public double getValeur() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.valeur;
    }

    @objid ("15cdcdec-9bf6-4d54-be72-8971f715fca6")
    public void setValeur(double value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.valeur = value;
    }

    @objid ("1d20ea9d-8fc6-44b3-abd1-d29b232c2754")
    public LienProbabiliste(List<Noeud> noeuds) {
    }

}
