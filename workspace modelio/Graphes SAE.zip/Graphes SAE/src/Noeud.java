import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("52e71b57-6b70-428a-9dba-67f992c7fca0")
public abstract class Noeud {
    @objid ("7053b121-2452-4e4f-aca2-8cc08bb91989")
    private String nom;

    @objid ("47017499-a71b-469e-8808-45d1639562ef")
    private double posX;

    @objid ("d2d63628-2e17-44b3-8aab-fe3342fbe5ee")
    private double posY;

    @objid ("b1007e74-1a77-4c58-9f3c-e0b51924dfe9")
    private double radius;

    @objid ("f492a69c-3abb-40c4-8eb3-4949129bfbc9")
    public String getNom() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.nom;
    }

    @objid ("14679f31-cf7b-42d7-97d8-a6814f823b71")
    public void setNom(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.nom = value;
    }

    @objid ("98420bff-03b8-43fd-ac8d-03946ccd4318")
    public List<Double> getPositions() {
    }

    @objid ("a96a4bb0-63d3-467d-91ec-63af11c49aa3")
    public void setPositions(List<Double> positions) {
    }

    @objid ("01a173cd-bf5b-41a7-88fb-a1b976ba84a9")
    public double getRadius() {
    }

    @objid ("de10466f-682a-4ecf-8c51-0d4c8a4e16ed")
    public void setRadius(double radius) {
    }

    @objid ("407c893f-56fa-4736-9244-db5e274de1cf")
    public void dessinerNoeud() {
    }

    @objid ("fb58d8df-c9f2-409e-8ec2-1af3b3b70fd1")
    public Noeud(String nom, List<Double> pos, double radius);

}
