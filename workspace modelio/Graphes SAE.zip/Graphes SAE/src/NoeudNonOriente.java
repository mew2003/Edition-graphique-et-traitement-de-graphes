import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f5594f62-0a19-4d64-95d7-a47fdc1dea4a")
public class NoeudNonOriente extends Noeud {
    @objid ("24192246-aa29-48c7-b2ba-83f17f79f86f")
    public NoeudNonOriente(String nom, List<Double> pos, double radius) {
    }

}
