import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d6699f0a-0382-4554-b468-8e66b0cb42be")
public class NoeudOriente extends Noeud {
    @objid ("25d4209f-9801-4d80-b464-c294f817cda4")
    public NoeudOriente(String nom, List<Double> pos, double radius) {
    }

}
