import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d067b03e-bfdf-4cd5-8c44-9f80219cfc2c")
public class NoeudOrientePondere extends Noeud {
    @objid ("7f3d0353-bad1-414b-af95-a8d8e9070d50")
    public NoeudOrientePondere(String nom, List<Double> pos, double radius) {
    }

}
