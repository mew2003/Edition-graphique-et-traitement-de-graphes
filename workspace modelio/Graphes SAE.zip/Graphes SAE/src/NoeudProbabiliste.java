import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d076a790-3950-4846-906b-54fa89c43e93")
public class NoeudProbabiliste extends Noeud {
    @objid ("e755dde0-d893-4a9c-94e3-37d196e2872b")
    private double valeur;

    @objid ("95566627-c10d-4a5c-a788-8b6c9b3807ec")
    double getValeur() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.valeur;
    }

    @objid ("5a5fa2d7-3801-4304-bf2b-3149966d799d")
    void setValeur(double value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.valeur = value;
    }

    @objid ("834f9ddc-7865-4091-8d52-9d98eb59640b")
    public NoeudProbabiliste(String nom, List<Double> pos, double radius) {
    }

}
